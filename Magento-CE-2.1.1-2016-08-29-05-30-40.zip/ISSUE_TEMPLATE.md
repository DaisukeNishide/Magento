Steps to reproduce
--
1. Install Magento from `develop` branch.
2. [Example] Add Configurable Product to the cart.
3. ...

Expected result
--
1. [Example] Configurable product added to the shopping cart.
2. ...

Actual result
--
1. [Example] Error message appears: "Cannot save quote".
2. [Screenshot, logs]
3. ...
